# freak

Wayland gamma control — TUI and persistent daemon for wlroots compositors.

Controls red, green, blue channel gain, contrast and gamma correction in real time via `zwlr_gamma_control_v1`. Values survive session restarts through a systemd user service.

## Features

- Interactive TUI with per-channel sliders (0–100%, maps to −3…+2)
- Persistent daemon — gamma stays active between TUI sessions
- Preset system — `.freak` files, load by name or number key 1–9
- IPC socket at `/tmp/controller.sucker` for scripting
- `freakctl` CLI client
- Gay mode — sinusoidal full-spectrum color cycling in the UI
- Sway/mango window rules applied automatically (floating, sticky)

## Requirements

- Wayland compositor with `zwlr_gamma_control_manager_v1` (sway, river, hyprland, mango, …)
- `rust` / `cargo` to build

## Installation

### Arch Linux

```bash
cd pkg
makepkg -si
```

### From source

```bash
cargo build --release
install -Dm755 target/release/freak   ~/.local/bin/freak
install -Dm755 target/release/freakctl ~/.local/bin/freakctl
```

### crates.io

```bash
cargo install controlorfreak
```

Binaries are installed as `freak` and `freakctl`.

## Systemd service

```bash
systemctl --user enable --now freak
```

The service reads `WAYLAND_DISPLAY` from the environment. Ensure your compositor exports it to systemd — most do via `dbus-update-activation-environment` or `systemctl --user import-environment`.

If not, override the unit:

```bash
systemctl --user edit freak
```

```ini
[Service]
Environment=WAYLAND_DISPLAY=wayland-0
Environment=XDG_RUNTIME_DIR=/run/user/1000
```

## Usage

```
freak              launch TUI
freak --daemon     run headless (used by systemd)

freakctl get
freakctl set red 75
freakctl set green 80
freakctl set blue 80
freakctl set contrast 82
freakctl set gamma 78
freakctl reset
freakctl load warm
freakctl save mypreset
freakctl presets
```

## TUI keys

| Key | Action |
|-----|--------|
| ↑ ↓ | select parameter |
| ← → | adjust value |
| r | reset all to neutral (80% = value 1.0) |
| s | save current values as preset |
| p | open preset panel |
| h | toggle help |
| c | config info |
| 1–9 | load preset by index |
| q | quit |

Inside preset panel: Enter loads, Del deletes, Esc closes.

## Value mapping

Sliders show 0–100%. Internally this maps to −3.0…+2.0 passed to the gamma ramp formula. Neutral (identity ramp) is at **80%** for all parameters.

```
internal = (percent / 100) × 5 − 3
```

Reset sets all parameters to 80% (internal value 1.0).

## Presets

Preset files live in `~/.config/controlorfreak/presets/`. File name without extension is the preset name.

Format (TOML):

```toml
red      = 86.0
green    = 86.0
blue     = 86.0
contrast = 81.0
gamma    = 83.0
```

Bundled presets:

| Preset | Description |
|--------|-------------|
| neutral | All parameters at 81 — close to identity |
| warm | Warm tone, reduced blue |
| cool | Slightly elevated blue |
| cinema | Reduced gamma, cinema-like contrast |
| freakshow | Default balanced profile |
| CODE | Reduced brightness for long coding sessions |
| acerbudget | Tuned for Acer budget panels |
| asus_oled | Tuned for ASUS OLED panels |
| lenovolegions | Tuned for Lenovo Legion displays |

## Configuration

Create `config.toml` in the working directory or `~/.config/wlauncher/config.ini`:

```toml
[colors]
mode = "gay"
```

`mode = "gay"` enables full-spectrum sinusoidal color cycling across all UI elements.

## IPC protocol

Line-based text over Unix socket `/tmp/controller.sucker`:

```
GET                          → JSON with current values
SET <field> <0-100>          → OK
RESET                        → OK
LOAD <preset>                → OK / ERROR: ...
SAVE <preset>                → OK / ERROR: ...
PRESETS                      → JSON array of preset names
```

## License

MIT
