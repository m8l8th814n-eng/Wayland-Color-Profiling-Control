fn main() {
    println!("cargo:rerun-if-changed=info.txt");
}
