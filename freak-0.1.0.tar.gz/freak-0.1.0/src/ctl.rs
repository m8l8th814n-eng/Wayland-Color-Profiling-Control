use std::io::{BufRead, BufReader, Write};
use std::os::unix::net::UnixStream;

const SOCKET_PATH: &str = "/tmp/controller.sucker";

fn usage() {
    eprintln!("controlfreakctl <command> [args]");
    eprintln!("  get");
    eprintln!("  set <field> <0-100>");
    eprintln!("  reset");
    eprintln!("  load <preset>");
    eprintln!("  save <preset>");
    eprintln!("  presets");
}

fn send(cmd: &str) -> Option<String> {
    let mut stream = UnixStream::connect(SOCKET_PATH).ok()?;
    writeln!(stream, "{}", cmd).ok()?;
    let mut reader = BufReader::new(stream);
    let mut line = String::new();
    reader.read_line(&mut line).ok()?;
    Some(line.trim().to_string())
}

fn main() {
    let args: Vec<String> = std::env::args().collect();
    if args.len() < 2 {
        usage();
        std::process::exit(1);
    }
    let cmd = match args[1].as_str() {
        "get" => "GET".to_string(),
        "reset" => "RESET".to_string(),
        "presets" => "PRESETS".to_string(),
        "set" if args.len() >= 4 => format!("SET {} {}", args[2], args[3]),
        "load" if args.len() >= 3 => format!("LOAD {}", args[2]),
        "save" if args.len() >= 3 => format!("SAVE {}", args[2]),
        _ => {
            usage();
            std::process::exit(1);
        }
    };
    match send(&cmd) {
        Some(resp) => println!("{}", resp),
        None => {
            eprintln!("error: could not connect to {}", SOCKET_PATH);
            std::process::exit(1);
        }
    }
}
