use std::fs;
use std::path::PathBuf;

#[derive(Clone, Debug)]
pub struct AppConfig {
    pub color_mode: ColorMode,
}

#[derive(Clone, Debug, PartialEq)]
pub enum ColorMode {
    Gay,
    Default,
}

impl Default for AppConfig {
    fn default() -> Self {
        Self {
            color_mode: ColorMode::Default,
        }
    }
}

pub fn load() -> AppConfig {
    if let Some(cfg) = try_load_toml() {
        return cfg;
    }
    if let Some(cfg) = try_load_ini() {
        return cfg;
    }
    AppConfig::default()
}

fn try_load_toml() -> Option<AppConfig> {
    let content = fs::read_to_string("config.toml").ok()?;
    let table: toml::Value = content.parse().ok()?;
    let mode = table
        .get("colors")
        .and_then(|c| c.get("mode"))
        .and_then(|m| m.as_str())
        .unwrap_or("default");
    Some(AppConfig {
        color_mode: if mode == "gay" { ColorMode::Gay } else { ColorMode::Default },
    })
}

fn try_load_ini() -> Option<AppConfig> {
    let mut path = PathBuf::from(
        std::env::var("HOME").unwrap_or_else(|_| "/tmp".to_string()),
    );
    path.push(".config/wlauncher/config.ini");
    let content = fs::read_to_string(path).ok()?;
    let mode = content
        .lines()
        .find(|l| l.trim_start().starts_with("mode"))
        .and_then(|l| l.split('=').nth(1))
        .map(|v| v.trim())
        .unwrap_or("default");
    Some(AppConfig {
        color_mode: if mode == "gay" { ColorMode::Gay } else { ColorMode::Default },
    })
}
