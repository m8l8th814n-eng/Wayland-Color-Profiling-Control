use std::io::{Read, Write};
use std::os::unix::net::UnixStream;

const MAGIC: &[u8] = b"i3-ipc";

pub fn set_floating() {
    if let Ok(sock) = std::env::var("SWAYSOCK") {
        let _ = ipc_command(&sock, "floating enable");
        let _ = ipc_command(&sock, "sticky enable");
        let _ = ipc_command(&sock, "focus");
    }
}

fn ipc_command(sock_path: &str, cmd: &str) -> std::io::Result<()> {
    let mut stream = UnixStream::connect(sock_path)?;
    let payload = cmd.as_bytes();
    let mut msg = Vec::with_capacity(14 + payload.len());
    msg.extend_from_slice(MAGIC);
    msg.extend_from_slice(&(payload.len() as u32).to_le_bytes());
    msg.extend_from_slice(&0u32.to_le_bytes());
    msg.extend_from_slice(payload);
    stream.write_all(&msg)?;
    let mut header = [0u8; 14];
    let _ = stream.read_exact(&mut header);
    Ok(())
}
