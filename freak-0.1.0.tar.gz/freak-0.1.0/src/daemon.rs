use crate::{
    gamma::GammaClient,
    ipc::{parse_cmd, params_to_json, Cmd, SOCKET_PATH},
    params::Params,
    preset::{list_presets, load_preset, load_state, save_preset, save_state},
};
use std::{
    io::{BufRead, BufReader, Write},
    os::unix::net::{UnixListener, UnixStream},
    sync::{Arc, Mutex},
    time::Duration,
};

pub fn run() {
    let params = Arc::new(Mutex::new(load_state()));
    let gamma_params = Arc::clone(&params);

    let (tx, rx) = std::sync::mpsc::channel::<()>();

    std::thread::spawn(move || {
        let mut client = match GammaClient::connect() {
            Some(c) => c,
            None => {
                eprintln!("controlorfreak: failed to connect to Wayland");
                return;
            }
        };
        if !client.acquire_controls() {
            eprintln!("controlorfreak: failed to acquire gamma controls");
            return;
        }
        {
            let p = gamma_params.lock().unwrap();
            client.apply(&p);
        }
        loop {
            let _ = rx.recv_timeout(Duration::from_millis(50));
            client.dispatch();
            if let Ok(p) = gamma_params.lock() {
                client.apply(&p);
            }
        }
    });

    let _ = std::fs::remove_file(SOCKET_PATH);
    let listener = match UnixListener::bind(SOCKET_PATH) {
        Ok(l) => l,
        Err(e) => {
            eprintln!("controlorfreak: bind failed: {}", e);
            return;
        }
    };

    for stream in listener.incoming() {
        match stream {
            Ok(s) => {
                let params_ref = Arc::clone(&params);
                let tx_ref = tx.clone();
                std::thread::spawn(move || handle_client(s, params_ref, tx_ref));
            }
            Err(_) => break,
        }
    }
}

fn handle_client(
    stream: UnixStream,
    params: Arc<Mutex<Params>>,
    tx: std::sync::mpsc::Sender<()>,
) {
    let mut writer = stream.try_clone().ok();
    let reader = BufReader::new(stream);
    for line in reader.lines().flatten() {
        let response = match parse_cmd(&line) {
            Some(Cmd::Get) => {
                let p = params.lock().unwrap();
                params_to_json(&p)
            }
            Some(Cmd::Reset) => {
                let new = Params::reset();
                save_state(&new);
                *params.lock().unwrap() = new;
                let _ = tx.send(());
                "OK".to_string()
            }
            Some(Cmd::Set { field, value }) => {
                let mut p = params.lock().unwrap();
                match field.as_str() {
                    "red" => p.red = value.clamp(0.0, 100.0),
                    "green" => p.green = value.clamp(0.0, 100.0),
                    "blue" => p.blue = value.clamp(0.0, 100.0),
                    "contrast" => p.contrast = value.clamp(0.0, 100.0),
                    "gamma" => p.gamma = value.clamp(0.0, 100.0),
                    _ => return,
                }
                save_state(&p);
                let _ = tx.send(());
                "OK".to_string()
            }
            Some(Cmd::Load(name)) => {
                match load_preset(&name) {
                    Some(preset) => {
                        save_state(&preset);
                        *params.lock().unwrap() = preset;
                        let _ = tx.send(());
                        "OK".to_string()
                    }
                    None => format!("ERROR: preset '{}' not found", name),
                }
            }
            Some(Cmd::Save(name)) => {
                let p = params.lock().unwrap();
                match save_preset(&name, &p) {
                    Ok(_) => "OK".to_string(),
                    Err(e) => format!("ERROR: {}", e),
                }
            }
            Some(Cmd::ListPresets) => {
                let presets = list_presets();
                format!("[{}]", presets.iter().map(|s| format!("\"{}\"", s)).collect::<Vec<_>>().join(","))
            }
            None => "ERROR: unknown command".to_string(),
        };
        if let Some(ref mut w) = writer {
            let _ = writeln!(w, "{}", response);
        }
    }
}
