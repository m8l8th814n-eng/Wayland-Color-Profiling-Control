use crate::params::Params;
use std::fs;
use std::path::PathBuf;

pub fn preset_dir() -> PathBuf {
    let mut p = dirs_home();
    p.push(".config/controlorfreak/presets");
    p
}

pub fn state_file() -> PathBuf {
    let mut p = dirs_home();
    p.push(".config/controlorfreak/state.freak");
    p
}

fn dirs_home() -> PathBuf {
    std::env::var("HOME")
        .map(PathBuf::from)
        .unwrap_or_else(|_| PathBuf::from("/tmp"))
}

pub fn load_preset(name: &str) -> Option<Params> {
    let mut path = preset_dir();
    path.push(format!("{}.freak", name));
    let content = fs::read_to_string(&path).ok()?;
    toml::from_str(&content).ok()
}

pub fn save_preset(name: &str, params: &Params) -> std::io::Result<()> {
    let dir = preset_dir();
    fs::create_dir_all(&dir)?;
    let mut path = dir;
    path.push(format!("{}.freak", name));
    let content = toml::to_string(params).unwrap_or_default();
    fs::write(path, content)
}

pub fn list_presets() -> Vec<String> {
    let dir = preset_dir();
    fs::read_dir(&dir)
        .map(|entries| {
            entries
                .flatten()
                .filter_map(|e| {
                    let name = e.file_name();
                    let s = name.to_string_lossy();
                    if s.ends_with(".freak") {
                        Some(s[..s.len() - 6].to_string())
                    } else {
                        None
                    }
                })
                .collect()
        })
        .unwrap_or_default()
}

pub fn load_state() -> Params {
    let path = state_file();
    fs::read_to_string(&path)
        .ok()
        .and_then(|s| toml::from_str(&s).ok())
        .unwrap_or_default()
}

pub fn save_state(params: &Params) {
    let path = state_file();
    if let Some(parent) = path.parent() {
        let _ = fs::create_dir_all(parent);
    }
    if let Ok(content) = toml::to_string(params) {
        let _ = fs::write(path, content);
    }
}
