use serde::{Deserialize, Serialize};

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct Params {
    pub red: f64,
    pub green: f64,
    pub blue: f64,
    pub contrast: f64,
    pub gamma: f64,
}

impl Default for Params {
    fn default() -> Self {
        Self {
            red: 80.0,
            green: 80.0,
            blue: 80.0,
            contrast: 80.0,
            gamma: 80.0,
        }
    }
}

impl Params {
    pub fn reset() -> Self {
        Self::default()
    }

    pub fn raw_red(&self) -> f64 {
        pct_to_val(self.red)
    }
    pub fn raw_green(&self) -> f64 {
        pct_to_val(self.green)
    }
    pub fn raw_blue(&self) -> f64 {
        pct_to_val(self.blue)
    }
    pub fn raw_contrast(&self) -> f64 {
        pct_to_val(self.contrast)
    }
    pub fn raw_gamma(&self) -> f64 {
        pct_to_val(self.gamma)
    }
}

pub fn pct_to_val(p: f64) -> f64 {
    (p / 100.0) * 5.0 - 3.0
}

pub fn val_to_pct(v: f64) -> f64 {
    (v + 3.0) / 5.0 * 100.0
}
