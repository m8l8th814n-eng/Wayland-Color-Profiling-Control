[](green)\
[](bg:yellow fg:green)\
[](fg:yellow bg:green)\
[](fg:green bg:crust)\
[](fg:crust bg:lavender)\
[ ](fg:lavender)\
SUSE = ""
Raspbian = "󰐿"
Mint = "󰣭"
Macos = "󰀵"
Manjaro = ""
Linux = "󰌽"
Fedora = "󰣛"
CachyOS = " 󰣨 "
Alpine = ""
Amazon = ""
Android = ""
AOSC = ""
Arch = "󰣇"
Artix = "󰣇"
CentOS = ""
Debian = "󰣚"
Redhat = "󱄛"

symbol = " "
symbol = ""
symbol = ""
symbol = ""
symbol = " "
symbol = ""
symbol = ""
symbol = "!reefland! "
symbol = ""
symbol = "  "
vimcmd_symbol = '[❮](bold fg:green)'
vimcmd_replace_one_symbol = '[❮](bold fg:lavender)'
vimcmd_replace_symbol = '[❮](bold fg:lavender)'
vimcmd_visual_symbol = '[❮](bold fg:yellow)'

rosewater = "#31302F"
flamingo = "#1D2021"
pink = "#131620"
mauve = "#131620"
red = "#3C465B"
maroon = "#7184C1"
peach = "#7184C1"
yellow = "#131620"
green = "#3C465B"
teal = "#6D82B8"
sky = "#6D82B8"
sapphire = "#131620"
blue = "#6D82B8"
lavender = "#3C465B"
text = "#6D82B8"
surface0 = "#ccd0da"
surface1 = "#bcc0cc"
subtext1 = "#171A1A"
subtext0 = "#6D82B8"
overlay2 = "#3C465B"
overlay1 = "#5F5852"
overlay0 = "#8B8279"
surface2 = "#928374"
base = "#6D82B8"
mantle = "#1d2021"
crust = "#131620"

