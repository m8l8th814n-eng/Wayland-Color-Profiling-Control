#!/bin/bash
set -e

PKGVER=$(grep '^version' Cargo.toml | head -1 | grep -o '[0-9.]*')
NAME="freak-$PKGVER"

rm -rf "/tmp/$NAME"
mkdir -p "/tmp/$NAME"

rsync -a --exclude=target --exclude='.git' . "/tmp/$NAME/"

tar -czf "$NAME.tar.gz" -C /tmp "$NAME"
rm -rf "/tmp/$NAME"

echo "created $NAME.tar.gz"
echo ""
echo "to build package:"
echo "  cp $NAME.tar.gz pkg/ && cd pkg && makepkg -si"
